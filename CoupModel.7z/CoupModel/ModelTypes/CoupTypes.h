class SimB;
class P;
class Tab;
class Ps;
class Sw;
class F;
class CDB;
#ifndef MAXSIMVAL
#define MAXSIMVAL 16

#endif