#include "XXX_Functions.h"
#include "PhysConst.h"



XXX_Functions::XXX_Functions(void)
{
   
}


XXX_Functions::~XXX_Functions(void){
    
}

bool XXX_Functions::Def()
{
	

	




return true;
}


double ThrougFallFunc() {
    return 0.0;
}


