#include "ModelConst.h"
ModelConst::ModelConst(){
	DayLength=720.;
	JYearNum=0;
	JDayNum=1.;
	SecPerDay =86400. ;//   ! Converstion for heat flux
}
ModelConst::~ModelConst()
{

}