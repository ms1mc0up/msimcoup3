#pragma once
#include <string>
//#include "../Base/ModelType.h"
#include "./SimModule.h"
class XXX_Functions : public SimModule
{
	public:
		XXX_Functions(void);
		~XXX_Functions(void);
		bool Def();
		double ThrougFallFunc() ;

		

};


