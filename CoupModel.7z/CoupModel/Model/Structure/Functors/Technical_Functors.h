#pragma once
enum class TimeResolution_Sw { WITHIN_DAY, DAILY_MEAN, HOURLY, TEN_MINUTES };
