#pragma once







class Plant_Functions : public SimModule
{
	public:
		Plant_Functions(void);
		~Plant_Functions(void);

		bool FunctionDef();



};

