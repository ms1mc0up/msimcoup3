#include "Plant_Functions.h"
#include "../SOIL\SoilModel.h"
#include "../Atmosphere\AtmModel.h"
#include "../Plant_NC\PlantOrgModel.h"
#include "../Structure\StructureModel.h"

Plant_Functions::Plant_Functions(void)
{

}
Plant_Functions::~Plant_Functions(void)
{
}



