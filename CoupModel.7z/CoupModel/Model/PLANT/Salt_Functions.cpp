#include "Salt_Functions.h"
#include "../SOIL/SoilModel.h"
#include "../PLANT_NC/NC_Plant.h"
#include "../Structure/Additional_Variables.h"
#include "../SOIL/Soil_HeatF.h"
#include "../Atmosphere/Irrigation.h"

Salt_Functions::Salt_Functions(void)
{

}
Salt_Functions::~Salt_Functions(void)
{
}





